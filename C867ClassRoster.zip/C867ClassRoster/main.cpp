//
//  main.cpp
//  C867ClassRoster
//
//  Created by Priscilla Hennig on 1/9/22.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
